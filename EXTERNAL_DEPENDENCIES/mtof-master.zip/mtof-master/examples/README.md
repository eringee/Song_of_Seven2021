Examples for the mtof library
