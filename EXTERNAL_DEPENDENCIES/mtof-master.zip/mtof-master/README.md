# mtof
In Arduino, convert MIDI pitch values to frequency values and vice-versa. 
 
To install this library, download the .zip file and move the decompressed folder to Documents/Arduino/libraries/.
 
http://little-scale.com/
